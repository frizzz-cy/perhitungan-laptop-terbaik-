<?php
include 'koneksi.php'; // Pastikan koneksi terhubung

$id = $_GET['id']; // ambil id dari URL
$hapus = $koneksi->query("DELETE FROM laptop WHERE id = '$id'");

if ($hapus) {
    echo "<script>alert('Data berhasil dihapus'); window.location='?page=data_laptop';</script>";
} else {
    echo "<script>alert('Gagal menghapus data'); window.location='?page=data_laptop';</script>";
}
?>