<?php
include_once __DIR__ . '/../koneksi.php';

$query = $koneksi->query("SELECT id, `COL 1` as nama, `COL 6` as merk, `COL 7` as harga, `COL 8` as ram, `COL 9` as storage FROM laptop");

$data = [];
while ($row = $query->fetch_assoc()) {
    if (strtolower(trim($row['merk'])) == 'merk laptop') continue;

    $harga = $row['harga'];
    $ram = floatval(preg_replace('/[^0-9.]/', '', $row['ram']));
    $storage = floatval(preg_replace('/[^0-9.]/', '', $row['storage']));

    $data[] = [
        'id' => $row['id'],
        'nama' => $row['nama'],
        'merk' => $row['merk'],
        'harga' => $harga,
        'ram' => $ram,
        'storage' => $storage
    ];
}

$ram_values = array_column($data, 'ram');
$storage_values = array_column($data, 'storage');

$min_ram = min($ram_values);
$max_ram = max($ram_values);

$min_storage = min($storage_values);
$max_storage = max($storage_values);

function normalize($value, $min, $max) {
    return ($max == $min) ? 0 : ($value - $min) / ($max - $min);
}
?>

<!-- STYLE -->
<style>
    html, body {
        overflow-x: hidden;
        margin: 0;
        padding: 0;
    }

    .table thead.table-dark th {
        background-color: #0a2647 !important;
        color: #fff !important;
    }
</style>
<!-- TITLE -->
<h2>NORMALISASI DATA LAPTOP</h2>

<!-- TABLE -->
<!-- TABLE -->
<div class="table-responsive">
    <table id="tabelnormal" class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Brand Laptop</th>
                <th>Harga</th>
                <th>RAM</th>
                <th>Normalisasi RAM</th>
                <th>Storage (SSD)</th>
                <th>Normalisasi Storage</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($data as $row) {
                $norm_ram = normalize($row['ram'], $min_ram, $max_ram);
                $norm_storage = normalize($row['storage'], $min_storage, $max_storage);

                echo "<tr>
                    <td>{$no}</td>
                    <td>" . htmlspecialchars($row['nama']) . "</td>
                    <td>" . htmlspecialchars($row['merk']) . "</td>
                    <td>{$row['harga']}</td>
                    <td>{$row['ram']} GB</td>
                    <td>" . number_format($norm_ram, 3) . "</td>
                    <td>{$row['storage']} GB</td>
                    <td>" . number_format($norm_storage, 3) . "</td>
                </tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
</div>


<!-- DATATABLES -->
<script>
    $(document).ready(function () {
        $('#tabelNormalisasi').DataTable({
            scrollX: true
        });
    });
</script>
