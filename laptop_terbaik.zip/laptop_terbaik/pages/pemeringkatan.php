<?php
include_once __DIR__ . '/../koneksi.php';

// Ambil data merk laptop saja
$query = $koneksi->query("SELECT `COL 6` as merk FROM laptop");

$frekuensi = [];
$merk_asli = [];

while ($row = $query->fetch_assoc()) {
    $merk_raw = trim($row['merk']);
    $merk = strtolower(trim(preg_replace('/[^a-zA-Z0-9]/', '', $merk_raw)));


    // Lewati baris header atau kosong
    if ($merk === 'merk laptop' || $merk === '') continue;

    if (!isset($frekuensi[$merk])) {
        $frekuensi[$merk] = 1;
        $merk_asli[$merk] = $merk_raw; // simpan merk asli untuk tampilan
    } else {
        $frekuensi[$merk]++;
    }
}

// Urutkan berdasarkan jumlah terbanyak
arsort($frekuensi);
?>

<h2>PEMERINGKATAN MERK LAPTOP TERBANYAK</h2>

<style>
    html, body {
        overflow-x: hidden;
        margin: 0;
        padding: 0;
    }

    .table thead.table-dark th {
        background-color:#0a2647  !important;
        color: #fff !important;
    }
</style>

<div class="table-responsive" style="max-height: 600px; overflow-y: auto;">
    <table id="tabelperingkat" class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
        <tr>
            <th>Rank</th>
            <th>Brand Laptop</th>
            <th>Jumlah Kemunculan</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $rank = 1;
        foreach ($frekuensi as $merk => $jumlah) {
            $nama_merk = htmlspecialchars($merk_asli[$merk]);
            echo "<tr>
                    <td>{$rank}</td>
                    <td>{$nama_merk}</td>
                    <td>{$jumlah}</td>
                </tr>";
            $rank++;
        }
        ?>
    </tbody>
</table>
</div>

<script>
    $(document).ready(function() {
        $('#tabelMerk').DataTable();
    });
</script>
