<style>
    html, body {
        overflow-x: hidden;
        margin: 0;
        padding: 0;
    }

    .table thead.table-dark th {
        background-color: #0a2647 !important;
        color: #fff !important;
    }
</style>

<h2>DATA LAPTOP</h2>

<div class="table-responsive" style="max-height: 600px; overflow-y: auto;">
    <table id="tabelLaptop" class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Brand Laptop</th>
                <th>Harga</th>
                <th>RAM</th>
                <th>Storage (SSD)</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query = $koneksi->query("SELECT id, `COL 1`, `COL 6`, `COL 7`, `COL 8`, `COL 9` FROM laptop");
            $no = 1;
            while ($row = $query->fetch_assoc()) {
                if (strtolower(trim($row['COL 6'])) == 'merk laptop') {
                    continue;
                }
                $id = $row['id'];
                echo "<tr>
                    <td>{$no}</td>
                    <td>{$row['COL 1']}</td>
                    <td>{$row['COL 6']}</td>
                    <td>{$row['COL 7']}</td>
                    <td>{$row['COL 8']}</td>
                    <td>{$row['COL 9']}</td>
                    <td class='aksi-col'>
                        <a href='?page=edit_laptop&id={$id}' class='btn btn-sm btn-warning'>Edit</a>
                        <a href='?page=hapus_laptop&id={$id}' class='btn btn-sm btn-danger' onclick=\"return confirm('Yakin ingin hapus data ini?')\">Hapus</a>
                    </td>
                </tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
</div>
