<?php
$id = intval($_GET['id']); // pastikan id berupa angka

// Ambil data awal
$query = $koneksi->query("SELECT * FROM laptop WHERE id = '$id'");
$data = $query->fetch_assoc();

if (!$data) {
    echo "<script>alert('Data tidak ditemukan'); window.location='?page=data_laptop';</script>";
    exit;
}

// Proses update
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $merk = $_POST['merk'];
    $harga = $_POST['harga'];
    $ram = $_POST['ram'];
    $ssd = $_POST['ssd'];

    $stmt = $koneksi->prepare("UPDATE laptop SET `COL 1` = ?, `COL 6` = ?, `COL 7` = ?, `COL 8` = ?, `COL 9` = ? WHERE `id` = ?");
    $stmt->bind_param("sssssi", $nama, $merk, $harga, $ram, $ssd, $id);
    $stmt->execute();

   if ($stmt->affected_rows > 0) {
    echo "<script>alert('Data berhasil diupdate'); window.location='?page=data_laptop';</script>";
    exit;
} else {
    echo "<script>alert('Tidak ada perubahan data');</script>";
}
}
?>


<!-- Tampilan Form Edit -->
<div class="container mt-5" style="max-width: 600px;">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Edit Data Laptop</h5>
        </div>
        <div class="card-body">
            <form method="post">
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" class="form-control" name="nama" id="nama" value="<?= htmlspecialchars($data['COL 1']) ?>"required>
                </div>
                <div class="mb-3">
                    <label for="merk" class="form-label">Merk Laptop</label>
                    <input type="text" class="form-control" name="merk" id="merk" value="<?= $data['COL 6'] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="harga" class="form-label">Harga</label>
                    <input type="text" class="form-control" name="harga" id="harga" value="<?= $data['COL 7'] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="ram" class="form-label">RAM (GB)</label>
                    <input type="text" class="form-control" name="ram" id="ram" value="<?= $data['COL 8'] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="ssd" class="form-label">SSD (GB)</label>
                    <input type="text" class="form-control" name="ssd" id="ssd" value="<?= $data['COL 9'] ?>" required>
                </div>
                <div class="text-end">
                    <a href="?page=data_laptop" class="btn btn-secondary">Batal</a>
                    <button type="submit" name="submit" class="btn btn-success">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>